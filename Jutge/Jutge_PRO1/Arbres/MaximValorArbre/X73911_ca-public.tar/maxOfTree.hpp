#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

// Pre: t és no buit
// Post: Retorna el màxim dels valors de t
int maxOfTree(BinaryTree<int> t);
