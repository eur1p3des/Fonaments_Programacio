#include "maxOfTree.hpp"


typedef BinaryTree<int> BT;


// Pre: t és no buit
// Post: Retorna el màxim dels valors de t
int maxOfTreeRec(BT& t)
{	
	int left = t.getRoot();
	int right = t.getRoot();
	if (!t.getLeft().isEmpty()) left = maxOfTreeRec(t.getLeft()); 
	if (!t.getRight().isEmpty()) right = maxOfTreeRec(t.getRight());
	
	if (left > right and left >= t.getRoot()) return left;
	else if (right >= left and right >= t.getRoot()) return right;
	return t.getRoot();
}

int maxOfTree(BT t)
{
	return maxOfTreeRec(t);
}

