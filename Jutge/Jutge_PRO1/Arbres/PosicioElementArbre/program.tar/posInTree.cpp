#include "posInTree.hpp"

using namespace std;


list<int> posInTreeRec(const BinaryTree<int>& t, int x){
	list<int> llista_buida;
	if (t.isEmpty()) return llista_buida;
	if (t.getRoot() == x )
	{
		list<int> llista;
		llista.push_back(x);
		return llista;
	} 
	list<int> llistaEsquerre = posInTreeRec(t.getLeft(), x);
	if (not llistaEsquerre.empty())
	{
		llistaEsquerre.push_front(t.getRoot());
		return llistaEsquerre;
	}
	
	list<int> llistaDreta = posInTreeRec(t.getRight(), x);
	if (not llistaDreta.empty())
	{
		llistaDreta.push_front(t.getRoot());
		return llistaDreta;
	}
	
	return llista_buida;
}



// Pre:  t no té repetits
// Post: retorna la llista de valors que es troben en el camí des de l'arrel
//       fins la posició de x en t. En cas que x no es trobi a t, retorna
//       una llista buida.
list<int> posInTree(const BinaryTree<int> t, int x)
{
	return posInTreeRec(t,x);
}

