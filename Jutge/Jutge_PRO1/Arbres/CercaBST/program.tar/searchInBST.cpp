#include <iostream>
#include <list>

using namespace std;

#include "BinaryTree.hpp"


bool searchInBSTRec(const BinaryTree<int>& t, int x)
{
    if (t.isEmpty()) return false;
    if (t.getRoot() == x)  return true;
    if (t.getRoot() > x)  return searchInBSTRec(t.getLeft(), x);
    if (t.getRoot() < x) return searchInBSTRec(t.getRight(), x);

}

// Pre: t és un BST
// Post: Retorna cert si i només si x apareix a t
bool searchInBST(BinaryTree<int> &t, int x){
    return searchInBSTRec(t, x);
}