#include "heightOfTree.hpp"

typedef BinaryTree<int> BT;




// Pre:
// Post: Retorna l'alçada de t
int heightOfTreeRec(BT& t)
{
	if (t.isEmpty()) return 0;	
	int left = heightOfTreeRec(t.getLeft());
	int right = heightOfTreeRec(t.getRight());
	if (left < right) return right+1;
	return left+1;
}


// Pre:
// Post: Retorna l'alçada de t
int heightOfTree(BT t)
{
	return heightOfTreeRec(t);
}
