#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

// Pre:
// Post: Retorna l'alçada de t
int heightOfTree(BinaryTree<int> t);