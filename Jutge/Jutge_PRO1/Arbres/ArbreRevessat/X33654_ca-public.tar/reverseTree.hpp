#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

// Pre:  
// Post: retorna el revessat de t.
BinaryTree<int> reverseTree(BinaryTree<int> t);