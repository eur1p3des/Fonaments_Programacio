#include "BinaryTree.hpp"

using namespace std;

typedef BinaryTree<int> BT;

//PRE: Rep l'arbre t i l'arbre buit r.
//POST: Retorna l'arbre r el cual es el rebessat de t.
//TERMINACIÓ: A cada cirda l'arbre t és més petit, fins a ser un arbre buit.
void reverseTreeRec(const BT& t, BT& r)
{
	if (t.isEmpty()) return;
	
	//Agafem l'arrel de t i la fiquem a r.
	r = BT(t.getRoot(), BT(), BT());
	
	
	//HI: El fill esquerre de l'arbre r, conté el revessat del fill dret de t.
	reverseTreeRec(t.getRight(), r.getLeft());
	//HI: El fill dret de l'arbre r, conté el revessat del fill esquerre de t.
	reverseTreeRec(t.getLeft(), r.getRight());
}

//PRE: Rep l'arbre t
//POST: Retorna l'arbre r el cual es el rebessat de t.
BT reverseTree(BT t)
{
	BT r;
	reverseTreeRec(t, r);
	return r;
}
