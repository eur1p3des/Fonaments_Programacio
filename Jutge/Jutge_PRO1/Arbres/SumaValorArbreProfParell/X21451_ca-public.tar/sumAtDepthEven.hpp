#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

// Pre:
// Post: Retorna la suma dels valors de t a profunditat parell
int sumAtDepthEven(BinaryTree<int> t);
