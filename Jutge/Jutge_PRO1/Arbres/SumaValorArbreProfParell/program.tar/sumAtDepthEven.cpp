#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

// Pre: suma >= 0 i cert.
// Post: Retorna la suma dels valors de t a profunditat parell
void sumAtDepthEvenRec(BinaryTree<int>& t, int iteracions, int& suma)
{
    if (not t.isEmpty())
    {
        if (iteracions%2 == 0) suma += t.getRoot();

        sumAtDepthEvenRec(t.getLeft(), iteracions+1, suma);
        sumAtDepthEvenRec(t.getRight(), iteracions+1, suma);
    }
}

// Pre:
// Post: Retorna la suma dels valors de t a profunditat parell
int sumAtDepthEven(BinaryTree<int> t)
{
    int iteracions = 0;
    int suma = 0;
    sumAtDepthEvenRec(t, iteracions, suma);
    return suma;
}
