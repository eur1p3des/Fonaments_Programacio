#include "sizeOfTree.hpp"

typedef BinaryTree<int> BT;


//PRE:
//POST: Retorna la mida de t
int sizeOfTreeRec(BT& t){
	if (t.isEmpty()) return 0;
	int sumLeft = sizeOfTreeRec(t.getLeft());
	int sumRight = sizeOfTreeRec(t.getRight());
	return 1 + sumLeft + sumRight;	
	
}


int sizeOfTree(BT t){
	int contador = 0;
	sizeOfTreeRec(t);
}
