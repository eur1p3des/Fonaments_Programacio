#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

// Pre:
// Post: Retorna la mida de t
int sizeOfTree(BinaryTree<int> t);
