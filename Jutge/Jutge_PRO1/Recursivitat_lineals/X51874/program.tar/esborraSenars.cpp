#include <stack>
#include "esborraSenars.hpp"
using namespace std;

/// Declaració de la funció que heu d'implementar.
void esborraSenars (stack<int>& P)
{
    int a;
    bool trobat = false;
    if (!P.empty())
    {
        int primer = P.top();
        if( primer%2 == 0 )
        {
            a = P.top();
            trobat = true;
        }
        P.pop();
        esborraSenars(P);
    }
    if (trobat == true) P.push(a);
}
